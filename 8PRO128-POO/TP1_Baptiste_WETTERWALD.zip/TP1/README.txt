Bonjour, j'ai réalisé ce travail seul.

Important : mon code utilise la méthode std::format(), disponible uniquement à partir de la version 20 de C++.

PS : Je me suis permis d'utiliser quelques notions que nous n'avons pas (encore) étudiées, à savoir une exception (de type overflow_error) que je throw lorsqu'on essaye de diviser par 0, l'instruction #pragma once, ainsi que l'attribut "[[nodiscard]]".
PPS : Le constructeur Complex() sans paramètre initialise la partie réelle et la partie imaginaire à 0.

Bonne correction
Baptiste WETTERWALD